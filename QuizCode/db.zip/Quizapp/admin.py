from django.contrib import admin

from Quizapp.models import Subject , Question
# Register your models here.
admin.site.register(Subject)
admin.site.register(Question)

